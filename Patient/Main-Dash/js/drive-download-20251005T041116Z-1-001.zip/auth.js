// Authentication: login, signup, forgot password, user agreement

document.addEventListener('DOMContentLoaded', () => {
    const loginModal = document.getElementById('loginModal');
    const closeLoginModalBtn = document.getElementById('closeLoginModalBtn');
    const loginForm = document.getElementById('loginForm');
    const loginEmailInput = document.getElementById('loginEmail');
    const loginPasswordInput = document.getElementById('loginPassword');
    const loginEmailError = document.getElementById('loginEmailError');
    const loginPasswordError = document.getElementById('loginPasswordError');
    const loginSuccessMessage = document.getElementById('loginSuccessMessage');
    const openLoginModalBtn = document.getElementById('openLoginModalBtn');
    const openLoginModalBtnMobile = document.getElementById('openLoginModalBtnMobile');

    const signupModal = document.getElementById('signupModal');
    const closeSignupModalBtn = document.getElementById('closeSignupModalBtn');
    const signupForm = document.getElementById('signupForm');
    const signupFirstNameInput = document.getElementById('signupFirstName');
    const signupLastNameInput = document.getElementById('signupLastName');
    const signupEmailInput = document.getElementById('signupEmail');
    const signupPasswordInput = document.getElementById('signupPassword');
    const signupConfirmPasswordInput = document.getElementById('signupConfirmPassword');
    const signupFirstNameError = document.getElementById('signupFirstNameError');
    const signupLastNameError = document.getElementById('signupLastNameError');
    const signupEmailError = document.getElementById('signupEmailError');
    const signupPasswordError = document.getElementById('signupPasswordError');
    const signupConfirmPasswordError = document.getElementById('signupConfirmPasswordError');
    const signupSuccessMessage = document.getElementById('signupSuccessMessage');
    const openSignupModalLink = document.getElementById('openSignupModalLink');

    const forgotPasswordModal = document.getElementById('forgotPasswordModal');
    const closeForgotPasswordModalBtn = document.getElementById('closeForgotPasswordModalBtn');
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    const forgotEmailInput = document.getElementById('forgotEmail');
    const forgotEmailError = document.getElementById('forgotEmailError');
    const forgotPasswordSuccessMessage = document.getElementById('forgotPasswordSuccessMessage');
    const backToLoginLink = document.getElementById('backToLoginLink');
    const forgotPasswordLink = document.getElementById('forgotPasswordLink');

    // Password toggle elements
    const toggleLoginPassword = document.getElementById('toggleLoginPassword');
    const loginPasswordIcon = document.getElementById('loginPasswordIcon');
    const toggleSignupPassword = document.getElementById('toggleSignupPassword');
    const signupPasswordIcon = document.getElementById('signupPasswordIcon');
    const toggleSignupConfirmPassword = document.getElementById('toggleSignupConfirmPassword');
    const signupConfirmPasswordIcon = document.getElementById('signupConfirmPasswordIcon');

    const userAgreementModal = document.getElementById('userAgreementModal');
    const closeUserAgreementBtn = document.getElementById('closeUserAgreementBtn');
    const agreeTermsCheckbox = document.getElementById('agreeTerms');
    const acceptAgreementBtn = document.getElementById('acceptAgreementBtn');
    const declineAgreementBtn = document.getElementById('declineAgreementBtn');
    const openSignupModalBtnNav = document.getElementById('openSignupModalBtnNav');
    const openSignupModalBtnMobileNav = document.getElementById('openSignupModalBtnMobileNav');

    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*_]).{8,}$/;
    const namePattern = /^[a-zA-Z\s'-]+$/;

    function togglePasswordVisibility(input, icon) {
        if (!input || !icon) return;
        if (input.type === 'password') { input.type = 'text'; icon.classList.remove('fa-eye-slash'); icon.classList.add('fa-eye'); }
        else { input.type = 'password'; icon.classList.remove('fa-eye'); icon.classList.add('fa-eye-slash'); }
    }

    if (toggleLoginPassword && loginPasswordInput && loginPasswordIcon) toggleLoginPassword.addEventListener('click', () => togglePasswordVisibility(loginPasswordInput, loginPasswordIcon));
    if (toggleSignupPassword && signupPasswordInput && signupPasswordIcon) toggleSignupPassword.addEventListener('click', () => togglePasswordVisibility(signupPasswordInput, signupPasswordIcon));
    if (toggleSignupConfirmPassword && signupConfirmPasswordInput && signupConfirmPasswordIcon) toggleSignupConfirmPassword.addEventListener('click', () => togglePasswordVisibility(signupConfirmPasswordInput, signupConfirmPasswordIcon));

    function openLoginModal(e) { if (e) e.preventDefault(); if (!loginModal) return; loginModal.classList.add('active'); signupModal && signupModal.classList.remove('active'); forgotPasswordModal && forgotPasswordModal.classList.remove('active'); loginEmailInput && loginEmailInput.focus(); }
    function closeLoginModal() { if (!loginModal || !loginForm) return; loginModal.classList.remove('active'); loginForm.reset(); loginEmailInput && loginEmailInput.classList.remove('error', 'success'); loginPasswordInput && loginPasswordInput.classList.remove('error', 'success'); if (loginEmailError) loginEmailError.style.display = 'none'; if (loginPasswordError) loginPasswordError.style.display = 'none'; if (loginSuccessMessage) loginSuccessMessage.style.display = 'none'; }
    function openSignupModal(e) { if (e) e.preventDefault(); if (!signupModal) return; signupModal.classList.add('active'); loginModal && loginModal.classList.remove('active'); forgotPasswordModal && forgotPasswordModal.classList.remove('active'); signupFirstNameInput && signupFirstNameInput.focus(); }
    function closeSignupModal() { if (!signupModal || !signupForm) return; signupModal.classList.remove('active'); signupForm.reset(); [signupFirstNameInput, signupLastNameInput, signupEmailInput, signupPasswordInput, signupConfirmPasswordInput].forEach(inp => inp && inp.classList.remove('error', 'success')); [signupFirstNameError, signupLastNameError, signupEmailError, signupPasswordError, signupConfirmPasswordError].forEach(el => el && (el.style.display = 'none')); if (signupSuccessMessage) signupSuccessMessage.style.display = 'none'; const profilePhotoDisplay = document.getElementById('profilePhotoDisplay'); const displayProfilePhoto = document.getElementById('displayProfilePhoto'); if (profilePhotoDisplay) profilePhotoDisplay.classList.add('hidden'); if (displayProfilePhoto) displayProfilePhoto.src = ''; }
    function openForgotPasswordModal(e) { if (e) e.preventDefault(); if (!forgotPasswordModal) return; forgotPasswordModal.classList.add('active'); loginModal && loginModal.classList.remove('active'); signupModal && signupModal.classList.remove('active'); forgotEmailInput && forgotEmailInput.focus(); }
    function closeForgotPasswordModal() { if (!forgotPasswordModal || !forgotPasswordForm) return; forgotPasswordModal.classList.remove('active'); forgotPasswordForm.reset(); if (forgotEmailInput) forgotEmailInput.classList.remove('error', 'success'); if (forgotEmailError) forgotEmailError.style.display = 'none'; if (forgotPasswordSuccessMessage) forgotPasswordSuccessMessage.style.display = 'none'; }

    if (openLoginModalBtn) openLoginModalBtn.addEventListener('click', openLoginModal);
    if (openLoginModalBtnMobile) openLoginModalBtnMobile.addEventListener('click', openLoginModal);
    if (closeLoginModalBtn) closeLoginModalBtn.addEventListener('click', closeLoginModal);
    if (loginModal) loginModal.addEventListener('click', (event) => { if (event.target === loginModal) closeLoginModal(); });
    if (openSignupModalLink) openSignupModalLink.addEventListener('click', openSignupModal);
    const openLoginModalLink = document.getElementById('openLoginModalLink');
    if (openLoginModalLink) openLoginModalLink.addEventListener('click', openLoginModal);
    if (closeSignupModalBtn) closeSignupModalBtn.addEventListener('click', closeSignupModal);
    if (signupModal) signupModal.addEventListener('click', (event) => { if (event.target === signupModal) closeSignupModal(); });
    if (forgotPasswordLink) forgotPasswordLink.addEventListener('click', openForgotPasswordModal);
    if (closeForgotPasswordModalBtn) closeForgotPasswordModalBtn.addEventListener('click', closeForgotPasswordModal);
    if (forgotPasswordModal) forgotPasswordModal.addEventListener('click', (event) => { if (event.target === forgotPasswordModal) closeForgotPasswordModal(); });
    if (backToLoginLink) backToLoginLink.addEventListener('click', openLoginModal);

    function showUserAgreement(e) { e.preventDefault(); userAgreementModal && userAgreementModal.classList.add('active'); }
    function closeUserAgreement() { userAgreementModal && userAgreementModal.classList.remove('active'); }
    if (openSignupModalBtnNav) openSignupModalBtnNav.addEventListener('click', showUserAgreement);
    if (openSignupModalBtnMobileNav) openSignupModalBtnMobileNav.addEventListener('click', showUserAgreement);
    if (declineAgreementBtn) declineAgreementBtn.addEventListener('click', closeUserAgreement);
    if (closeUserAgreementBtn) closeUserAgreementBtn.addEventListener('click', closeUserAgreement);
    if (agreeTermsCheckbox && acceptAgreementBtn) {
        agreeTermsCheckbox.addEventListener('change', (e) => { acceptAgreementBtn.disabled = !e.target.checked; });
        acceptAgreementBtn.addEventListener('click', () => { closeUserAgreement(); signupModal && signupModal.classList.add('active'); });
    }

    function validateEmail(email) { if (!emailPattern.test(email)) return { valid: false, message: 'Please enter a valid email address.' }; return { valid: true, message: 'Valid email address format.' }; }
    function validateInput(inputElement, pattern, errorElementId) {
        const errorElement = document.getElementById(errorElementId);
        const value = (inputElement && inputElement.value || '').trim();
        let isValid = true; let errorMessage = '';
        if (inputElement && inputElement.hasAttribute('required') && value === '') { isValid = false; errorMessage = 'This field is required.'; }
        else if (pattern && value !== '' && !pattern.test(value)) { isValid = false; if (inputElement.type === 'email') { const emailValidation = validateEmail(value); errorMessage = emailValidation.message; } else if (inputElement.type === 'password') { errorMessage = 'Password must be at least 6 characters.'; } else { errorMessage = `Please enter a valid ${(inputElement.placeholder || 'value').toLowerCase()}.`; } }
        if (inputElement) { if (isValid) { inputElement.classList.remove('error'); inputElement.classList.add('success'); if (errorElement) errorElement.style.display = 'none'; } else { inputElement.classList.remove('success'); inputElement.classList.add('error'); if (errorElement) { errorElement.style.display = 'block'; errorElement.textContent = errorMessage; } } }
        return isValid;
    }

    function validateConfirmPassword() {
        if (!signupConfirmPasswordInput || !signupPasswordInput) return false;
        const isValid = signupConfirmPasswordInput.value === signupPasswordInput.value && signupConfirmPasswordInput.value !== '';
        if (isValid) { signupConfirmPasswordInput.classList.remove('error'); signupConfirmPasswordInput.classList.add('success'); signupConfirmPasswordError && (signupConfirmPasswordError.style.display = 'none'); }
        else { signupConfirmPasswordInput.classList.remove('success'); signupConfirmPasswordInput.classList.add('error'); if (signupConfirmPasswordError) { signupConfirmPasswordError.style.display = 'block'; signupConfirmPasswordError.textContent = 'Passwords do not match.'; } }
        return isValid;
    }

    if (loginEmailInput) loginEmailInput.addEventListener('input', () => validateInput(loginEmailInput, emailPattern, 'loginEmailError'));
    if (loginPasswordInput) loginPasswordInput.addEventListener('input', () => validateInput(loginPasswordInput, /./, 'loginPasswordError'));
    if (signupFirstNameInput) signupFirstNameInput.addEventListener('input', () => validateInput(signupFirstNameInput, namePattern, 'signupFirstNameError'));
    if (signupLastNameInput) signupLastNameInput.addEventListener('input', () => validateInput(signupLastNameInput, namePattern, 'signupLastNameError'));
    if (signupEmailInput) signupEmailInput.addEventListener('input', () => validateInput(signupEmailInput, emailPattern, 'signupEmailError'));
    if (signupPasswordInput) signupPasswordInput.addEventListener('input', () => { validateInput(signupPasswordInput, passwordPattern, 'signupPasswordError'); if (signupConfirmPasswordInput && signupConfirmPasswordInput.value !== '') validateConfirmPassword(); });
    if (signupConfirmPasswordInput) signupConfirmPasswordInput.addEventListener('input', validateConfirmPassword);

    if (loginForm) loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const isEmailValid = validateInput(loginEmailInput, emailPattern, 'loginEmailError');
        const isPasswordValid = validateInput(loginPasswordInput, /./, 'loginPasswordError');
        if (!(isEmailValid && isPasswordValid)) return;
        const submitBtn = loginForm.querySelector('button[type="submit"]');
        if (submitBtn) { submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...'; submitBtn.disabled = true; }
        try {
            const res = await fetch('Back-end/signup-db.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'login', email: loginEmailInput.value.trim(), password: loginPasswordInput.value }) });
            const data = await res.json().catch(() => ({ ok: false, error: 'Invalid response' }));
            if (res.ok && data.ok) {
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('userEmail', data.email);
                if (loginSuccessMessage) { loginSuccessMessage.textContent = 'Login successful! Redirecting...'; loginSuccessMessage.style.display = 'block'; loginSuccessMessage.classList.remove('text-red-500'); loginSuccessMessage.classList.add('text-green-600'); }
                closeLoginModal();
                setTimeout(() => { window.location.href = '../Patient-Dash/4Care-Patient.html'; }, 800);
            } else {
                if (loginSuccessMessage) { loginSuccessMessage.textContent = data.error || 'Wrong email or password.'; loginSuccessMessage.style.display = 'block'; loginSuccessMessage.classList.remove('text-green-600'); loginSuccessMessage.classList.add('text-red-500'); }
            }
        } catch (_) {
            if (loginSuccessMessage) { loginSuccessMessage.textContent = 'Network error, please try again.'; loginSuccessMessage.style.display = 'block'; loginSuccessMessage.classList.remove('text-green-600'); loginSuccessMessage.classList.add('text-red-500'); }
        } finally {
            if (submitBtn) { submitBtn.innerHTML = 'Login'; submitBtn.disabled = false; }
        }
    });

    if (signupForm) signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const isFirstNameValid = validateInput(signupFirstNameInput, namePattern, 'signupFirstNameError');
        const isLastNameValid = validateInput(signupLastNameInput, namePattern, 'signupLastNameError');
        const isEmailValid = validateInput(signupEmailInput, emailPattern, 'signupEmailError');
        const isPasswordValid = validateInput(signupPasswordInput, passwordPattern, 'signupPasswordError');
        const isConfirmPasswordValid = validateConfirmPassword();
        if (!(isFirstNameValid && isLastNameValid && isEmailValid && isPasswordValid && isConfirmPasswordValid)) { signupForm.classList.add('shake'); setTimeout(() => signupForm.classList.remove('shake'), 400); return; }
        const submitBtn = signupForm.querySelector('button[type="submit"]');
        if (submitBtn) { submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...'; submitBtn.disabled = true; }
        try {
            const res = await fetch('Back-end/signup-db.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ firstName: signupFirstNameInput.value.trim(), lastName: signupLastNameInput.value.trim(), email: signupEmailInput.value.trim(), password: signupPasswordInput.value }) });
            const raw = await res.text();
            let data; try { data = JSON.parse(raw); } catch { data = { ok: false, error: 'Invalid response', raw }; }
            if (res.ok && data.ok) {
                try { localStorage.setItem('userEmail', signupEmailInput.value.trim()); } catch {}
                if (signupSuccessMessage) { signupSuccessMessage.textContent = 'Registration successful! Please complete your patient details.'; signupSuccessMessage.classList.remove('hidden'); signupSuccessMessage.style.display = 'block'; signupSuccessMessage.classList.remove('text-red-500'); signupSuccessMessage.classList.add('text-green-600'); signupSuccessMessage.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
                setTimeout(() => { if (window.openPatientDetailsModal) window.openPatientDetailsModal(); closeSignupModal(); }, 1200);
            } else {
                if (signupSuccessMessage) { signupSuccessMessage.textContent = (data && data.error) ? data.error : 'Registration failed. Please try again.'; signupSuccessMessage.classList.remove('hidden'); signupSuccessMessage.style.display = 'block'; signupSuccessMessage.classList.remove('text-green-600'); signupSuccessMessage.classList.add('text-red-500'); signupSuccessMessage.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
            }
        } catch (err) {
            if (signupSuccessMessage) { signupSuccessMessage.textContent = 'Network error. Please try again.'; signupSuccessMessage.classList.remove('hidden'); signupSuccessMessage.style.display = 'block'; signupSuccessMessage.classList.remove('text-green-600'); signupSuccessMessage.classList.add('text-red-500'); signupSuccessMessage.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
        } finally { if (submitBtn) { submitBtn.innerHTML = 'Sign Up'; submitBtn.disabled = false; } }
    });

    if (forgotPasswordForm) forgotPasswordForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const ok = (function(){ if (!forgotEmailInput) return false; const v = (forgotEmailInput.value || '').trim(); const valid = emailPattern.test(v); if (valid) { forgotEmailInput.classList.remove('error'); forgotEmailInput.classList.add('success'); if (forgotEmailError) forgotEmailError.style.display = 'none'; } else { forgotEmailInput.classList.remove('success'); forgotEmailInput.classList.add('error'); if (forgotEmailError) { forgotEmailError.style.display = 'block'; forgotEmailError.textContent = 'Please enter a valid email address.'; } } return valid; })();
        if (!ok) { forgotPasswordForm.classList.add('shake'); setTimeout(() => forgotPasswordForm.classList.remove('shake'), 400); return; }
        const submitBtn = forgotPasswordForm.querySelector('button[type="submit"]');
        if (submitBtn) { submitBtn.innerHTML = '<i class=\"fas fa-spinner fa-spin\"></i> Processing...'; submitBtn.disabled = true; }
        try {
            const email = (forgotEmailInput.value || '').trim();
            const params = new URLSearchParams(); 
            params.set('email', email);
            
            const res = await fetch('Back-end/forgot-password/send-pass-reset-simple.php', { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, 
                body: params.toString() 
            });
            
            const responseText = await res.text();
            console.log('Raw response:', responseText); // Debug log
            
            let data;
            try {
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error('JSON parse error:', parseError);
                console.error('Response text:', responseText);
                throw new Error('Invalid response from server. Please check console for details.');
            }
            
            if (data.ok) {
                if (forgotPasswordSuccessMessage) { 
                    forgotPasswordSuccessMessage.textContent = data.message; 
                    forgotPasswordSuccessMessage.style.display = 'block'; 
                    forgotPasswordSuccessMessage.classList.remove('text-red-500'); 
                    forgotPasswordSuccessMessage.classList.add('text-green-600'); 
                }
                setTimeout(() => { closeForgotPasswordModal(); openLoginModal(); }, 3000);
            } else {
                if (forgotPasswordSuccessMessage) { 
                    forgotPasswordSuccessMessage.textContent = data.error || 'An error occurred. Please try again.'; 
                    forgotPasswordSuccessMessage.style.display = 'block'; 
                    forgotPasswordSuccessMessage.classList.remove('text-green-600'); 
                    forgotPasswordSuccessMessage.classList.add('text-red-500'); 
                }
            }
        } catch (error) {
            console.error('Forgot password error:', error);
            if (forgotPasswordSuccessMessage) { 
                forgotPasswordSuccessMessage.textContent = 'Network error. Please try again.'; 
                forgotPasswordSuccessMessage.style.display = 'block'; 
                forgotPasswordSuccessMessage.classList.remove('text-green-600'); 
                forgotPasswordSuccessMessage.classList.add('text-red-500'); 
            }
        } finally { if (submitBtn) { submitBtn.innerHTML = 'Send Reset Link'; submitBtn.disabled = false; } }
    });
});


